//
//  PresentationCategoriesViewController.h
//  Presentation Judge
//
//  Created by Eden on 4/23/13.
//  Copyright (c) 2013 S. Alzheimer, L. Malenfant, E. Englert. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PresentationCategoriesViewController : UITableViewController{
    NSMutableArray *presentationTitles;
}

@end
