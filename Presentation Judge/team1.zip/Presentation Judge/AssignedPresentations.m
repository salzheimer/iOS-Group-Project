//
//  AssignedPresentations.m
//  Presentation Judge
//
//  Created by Eden on 4/7/13.
//  Copyright (c) 2013 S. Alzheimer, L. Malenfant, E. Englert. All rights reserved.
//

#import "AssignedPresentations.h"

@implementation AssignedPresentations

@end
