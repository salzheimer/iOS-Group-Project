//
//  RankingView.m
//  mstrDetailTest2
//
//  Created by skadoo on 5/9/13.
//  Copyright (c) 2013 skadoo. All rights reserved.
//

#import "RankingView.h"

@implementation RankingView
@synthesize ID;
@synthesize TextValue;
@end
