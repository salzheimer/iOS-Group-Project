//
//  mstrDetailTest2Tests.h
//  mstrDetailTest2Tests
//
//  Created by skadoo on 4/22/13.
//  Copyright (c) 2013 skadoo. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface mstrDetailTest2Tests : SenTestCase

@end
