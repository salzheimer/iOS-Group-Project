//
//  mstrDetailTest2Tests.m
//  mstrDetailTest2Tests
//
//  Created by skadoo on 4/22/13.
//  Copyright (c) 2013 skadoo. All rights reserved.
//

#import "mstrDetailTest2Tests.h"

@implementation mstrDetailTest2Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in mstrDetailTest2Tests");
}

@end
