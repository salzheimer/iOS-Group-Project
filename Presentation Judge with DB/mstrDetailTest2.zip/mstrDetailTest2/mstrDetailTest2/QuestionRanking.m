//
//  QuestionRanking.m
//  Presentation Judge
//
//  Created by skadoo on 4/15/13.
//  Copyright (c) 2013 S. Alzheimer, L. Malenfant, E. Englert. All rights reserved.
//

#import "QuestionRanking.h"

@implementation QuestionRanking

@synthesize ID;
@synthesize QuestionID;
@synthesize Ranking;
@synthesize PresentationID;

@end
