//
//  SubSection.m
//  Presentation Judge
//
//  Created by skadoo on 4/13/13.
//  Copyright (c) 2013 S. Alzheimer, L. Malenfant, E. Englert. All rights reserved.
//

#import "SubSection.h"

@implementation SubSection
@synthesize ID;
@synthesize SubSection_Name;
@end
