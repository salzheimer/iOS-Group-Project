//
//  QuestionRAnkingDBAccess.m
//  Presentation Judge
//
//  Created by skadoo on 4/15/13.
//  Copyright (c) 2013 S. Alzheimer, L. Malenfant, E. Englert. All rights reserved.
//

#import "QuestionRankingDBAccess.h"
#import "QuestionRanking.h"
@implementation QuestionRankingDBAccess
/*-(QuestionRanking *) getPresentationRanking: (int) presentationID
{
    

}*/
@end
